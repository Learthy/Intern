//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by StaticView.rc
//
#define IDR_MAINFRAME                   2
#define IDR_STATICVIEWTYPE              3
#define IDP_OLE_INIT_FAILED             100
#define IDD_ABOUTBOX                    100
#define IDD_ZOOMSET                     101
#define IDD_ZOOMSETOTHER                102
#define IDC_LIST1                       1000
#define IDC_EDIT1                       1001
#define IDC_EDITSTATIC					1002
#define IDC_EDITBOX						1003
#define IDC_ZOOMBUTTON					1004
#define ID_VIEW_PREVPAGE                32771
#define ID_VIEW_NEXTPAGE                32772
#define ID_VIEW_FIRSTPAGE               32773
#define ID_VIEW_LASTPAGE                32774
#define ID_VIEW_ACTUALSIZE              32775
#define ID_VIEW_FITPAGE                 32776
#define ID_VIEW_FITWIDTH                32777
#define ID_OTHER_COPYTOCLIPBOARD        32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
