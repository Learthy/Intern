//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DistillerCtrl.rc
//
#define IDD_DISTILLERCTRL_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_SELECTINPUT                 1000
#define IDC_STATUS_PROGBAR              1001
#define IDC_STATUS_PERCENT              1002
#define IDC_STATUS_LABEL                1003
#define IDC_STATUS_PAGECOUNT            1004
#define IDC_PROCESSFILE                 1005
#define IDC_INPUTFILE                   1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
