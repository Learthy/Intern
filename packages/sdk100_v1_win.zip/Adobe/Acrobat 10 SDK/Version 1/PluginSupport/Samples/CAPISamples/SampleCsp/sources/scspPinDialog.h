// scspPinDialog.h : 
// 	Entry point for launching the PIN dialog
//

#ifndef scspPinDialog_INCLUDED_
#define scspPinDialog_INCLUDED_

namespace scsp {
	bool getPinFromUser( sample::Buffer& outPin, HWND inHWND );

}

#endif //scspPinDialog_INCLUDED_