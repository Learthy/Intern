//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ParamDlg.rc
//
#define IDC_ELAPSED_TIME                1
#define IDC_DEFAULT                     3
#define IDD_PARAMRSRC                   101
#define IDD_DEBUGWINDOW                 102
#define IDD_TIMER_DLG                   103
#define IDD_DIALOG_PROMPT               104
#define IDD_DIALOG_ONETEXT              105
#define IDD_DIALOG_USERDATA             106
#define IDD_DIALOG_LIST                 108
#define IDD_DIALOG_HIER_LIST            109
#define IDD_DIALOG_PROMPT1              110
#define IDD_DIALOG_HIERARCHY_LIST       111
#define IDD_TEXT_INFO                   112
#define IDD_METADATA                    113
#define IDD_DEBUGWINDOW_RESIZE          114
#define IDC_PARAMBOX                    1000
#define IDC_TIME                        1000
#define IDC_OK                          1001
#define IDC_CANCEL                      1002
#define IDC_TEXTINFO                    1002
#define IDC_HELPTEXT                    1004
#define IDC_CLOSE                       1005
#define IDC_EDITWIN                     1006
#define IDC_CLEAR                       1007
#define IDC_EDIT_PROMPT                 1008
#define IDC_STATIC_LABEL                1009
#define IDC_CLEAR_RESIZE                1009
#define IDC_BUTTON_SELECT               1010
#define IDC_EDIT_USER_TEXT              1011
#define IDC_EDIT_USER_INT               1012
#define IDC_EDIT_USER_FLOAT             1013
#define IDC_BUTTON_USER_CHECK           1014
#define IDC_BUTTON_USER_RADIO1          1015
#define IDC_LISTBOX                     1016
#define IDC_BUTTON_USER_RADIO2          1016
#define IDC_EDIT_NEWITEM                1017
#define IDC_BUTTON_USER_RADIO3          1017
#define ID_BUTTON_OK                    1028
#define IDC_BUTTON_EXECUTE              1029
#define IDC_LIST_USERBOX                1032
#define IDC_BUTTON_DESCIPTION           1033
#define IDC_STATIC_ITEMDESCIP           1034
#define IDC_BUTTON_ADDITEM              1034
#define IDC_BUTTON_DELETEITEM           1035
#define IDC_EDIT_TEXT_FIELD             1035
#define IDC_SEARCH_URL                  1035
#define IDC_BUTTON_UP                   1036
#define IDC_ADD_URL                     1036
#define IDC_BUTTON_HELP                 1037
#define IDC_BUTTON_DOWN                 1038
#define IDC_ADD_METADATA                1038
#define IDC_STATIC_TITLE                1039
#define IDC_LISTBOX_DUMMY               1040
#define IDC_GET_METADATA                1049
#define IDC_DATA                        1050
#define IDC_URL_LIST                    1051

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
