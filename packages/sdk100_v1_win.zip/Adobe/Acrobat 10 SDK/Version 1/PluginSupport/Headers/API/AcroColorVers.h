/*
** AcroColorVers.h -- Acrobat Color header file
** 
** HFT names and versions
**
** This file is furnished to you by Adobe Systems Incorporated under the terms of the 
** Acrobat (r) Plug-ins Software Development Kit License Agreement.
** Copyright (C) 2002-2006 Adobe Systems Inc.  All Rights Reserved.
 */
 
#ifndef _H_AcroColorVers
#define _H_AcroColorVers


#endif /* _H_AcroColorVers */
