// This has been renamed
#include "IADMPoint.hpp"
